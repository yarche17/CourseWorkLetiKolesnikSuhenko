package com.example.leticoursework.server.model;

import com.example.leticoursework.server.entity.Songs;

public class SongsModel {
    private Long id;
    private String name;
    private String genre;
    private String duration;


    public static SongsModel toModel(Songs songs){
        SongsModel model = new SongsModel();
        model.setId(songs.getId());
        model.setName(songs.getName());
        model.setGenre(songs.getGenre());
        model.setDuration(songs.getDuration());
        return model;
    }


    public SongsModel() {
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
