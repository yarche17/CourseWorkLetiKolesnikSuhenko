package com.example.leticoursework.server.repository;

import com.example.leticoursework.server.entity.Musician;
import org.springframework.data.repository.CrudRepository;

public interface MusicianRepo extends CrudRepository<Musician, Long> {
}
