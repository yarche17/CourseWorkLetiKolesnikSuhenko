package com.example.leticoursework.client.gui.songs;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class SongsModelGui<Songs> extends AbstractListModel<Songs> {
    private List<Songs> list = new ArrayList<>();

    @Override
    public int getSize() {
        return list.size();
    }

    @Override
    public Songs getElementAt(int index) {
        return list.get(index);
    }

    public void setSongsList(List<Songs> songsList){
        list = songsList;
    }

    public void addSongs(Songs songs) {
        list.add(songs);
        fireIntervalAdded(songs,list.size()-1, list.size()-1);
    }

    public void delSongs(Songs songs) {
        list.remove(songs);
        fireIntervalRemoved(songs, list.size(), list.size());
    }

}
