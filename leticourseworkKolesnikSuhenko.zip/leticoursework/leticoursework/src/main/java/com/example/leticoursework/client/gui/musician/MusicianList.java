package com.example.leticoursework.client.gui.musician;

import com.example.leticoursework.server.entity.Musician;
import javax.swing.*;

public class MusicianList extends JList<Musician> {
    public MusicianList(){ //Создание списка и создание представления обьектов в списке
        super(new MusicianModelGui<>());
        setCellRenderer(new MusicianRenderer());
    }
    public MusicianModelGui getMusicianModel(){
        return (MusicianModelGui) getModel();
    }
}
