package com.example.leticoursework.client.gui.songs;

import com.example.leticoursework.server.entity.Songs;
import javax.swing.*;
import java.awt.*;

public class SongsRenderer extends DefaultListCellRenderer {
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus){
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        setText(((Songs)value).getName());
        return this;
    }
}
