package com.example.leticoursework.client.gui.musician;





import com.caucho.hessian.client.HessianProxyFactory;
import com.example.leticoursework.client.gui.ColoriesStyle;
import com.example.leticoursework.server.controller.MusicianController;
import com.example.leticoursework.server.entity.Musician;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;

public class MusicianPanel extends JPanel {
    public MusicianPanel(){
        ColoriesStyle coloriesStyle = new ColoriesStyle();

        MusicianList list = new MusicianList();
        list.setBackground(coloriesStyle.background1);


        JTextField nameField = new JTextField(18); //Строки ввода текста
        nameField.setFont(coloriesStyle.fontMain); nameField.setBackground(coloriesStyle.textBackground); nameField.setForeground(Color.white);
        JTextField fioField = new JTextField(18); //Строки ввода текста
        fioField.setFont(coloriesStyle.fontMain); fioField.setBackground(coloriesStyle.textBackground); fioField.setForeground(Color.white);
        JTextField countryField = new JTextField(12); //Строки ввода текста
        countryField.setFont(coloriesStyle.fontMain); countryField.setBackground(coloriesStyle.textBackground); countryField.setForeground(Color.white);
        JTextField b_dateField = new JTextField(7);
        b_dateField.setFont(coloriesStyle.fontMain); b_dateField.setBackground(coloriesStyle.textBackground); b_dateField.setForeground(Color.white);


        JLabel nameLabel = new JLabel("Nickname:"); //Текст
        nameLabel.setFont(coloriesStyle.fontHead); nameLabel.setForeground(coloriesStyle.text);
        JLabel fioLabel = new JLabel("Name & Surname:"); //Текст
        fioLabel.setFont(coloriesStyle.fontHead); fioLabel.setForeground(coloriesStyle.text);
        JLabel countryLabel = new JLabel("Country:"); //Текст
        countryLabel.setFont(coloriesStyle.fontHead); countryLabel.setForeground(coloriesStyle.text);
        JLabel b_dateLabel = new JLabel("Birthdate:");
        b_dateLabel.setFont(coloriesStyle.fontHead); b_dateLabel.setForeground(coloriesStyle.text);


        JButton addButton = new JButton("ADD");
        addButton.setOpaque(true);
        addButton.setBackground(Color.black); addButton.setForeground(Color.white); addButton.setFont(coloriesStyle.fontHead);
        JButton delButton = new JButton("DELETE");
        delButton.setOpaque(true);
        delButton.setBackground(Color.black); delButton.setForeground(Color.white); delButton.setFont(coloriesStyle.fontHead);
        JButton editButton = new JButton("EDIT");
        editButton.setOpaque(true);
        editButton.setBackground(Color.black); editButton.setForeground(Color.white); editButton.setFont(coloriesStyle.fontHead);


            addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s = JOptionPane.showInputDialog(MusicianPanel.this, "Product name", "Input", JOptionPane.QUESTION_MESSAGE);
                if (s != null) {
                    Musician musician = new Musician();
                    musician.setName(s);
                    try {
                        String url = "http://127.0.0.1:8080/musician";
                        HessianProxyFactory factory = new HessianProxyFactory();
                        MusicianController musicianController = (MusicianController) factory.create(MusicianController.class, url);
                        musicianController.addMusician(musician);
                        JOptionPane.showMessageDialog(null, "Пользователь успешно сохранён!");
                    }catch (MalformedURLException ex){
                        throw new RuntimeException(ex);
                    }
                }
            }
        });




        delButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Musician musician = list.getSelectedValue();
                list.getMusicianModel().delMusician(musician);

            }
        });


/*        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Team team = new Team();
                model.addTeam(team);
                list.
            }
        });
*/






        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setBackground(coloriesStyle.background1);
        toolBar.add(addButton);
        toolBar.add(delButton);
        toolBar.add(editButton);

        JPanel namePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        namePanel.setBackground(coloriesStyle.background);
        namePanel.add(nameLabel);
        namePanel.add(nameField);

        JPanel fioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        fioPanel.setBackground(coloriesStyle.background);
        fioPanel.add(fioLabel);
        fioPanel.add(fioField);

        JPanel countryPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        countryPanel.setBackground(coloriesStyle.background);
        countryPanel.add(countryLabel);
        countryPanel.add(countryField);


        JPanel b_datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        b_datePanel.setBackground(coloriesStyle.background);
        b_datePanel.add(b_dateLabel);
        b_datePanel.add(b_dateField);

        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.add(list, BorderLayout.CENTER);
        leftPanel.add(toolBar, BorderLayout.SOUTH);


        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(coloriesStyle.background);
        rightPanel.setLayout(new GridLayout(4,1));
        rightPanel.add(namePanel);
        rightPanel.add(fioPanel);
        rightPanel.add(countryPanel);
        rightPanel.add(b_datePanel);


        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setDividerLocation(715);


        setLayout(new BorderLayout());
        add(splitPane, BorderLayout.CENTER);
    }
}

