package com.example.leticoursework.server.model;

import com.example.leticoursework.server.entity.Concerts;

public class ConcertsModel {
    private Long id;
    private String address;
    private String city;
    private String date;
    private String time;

    public static ConcertsModel toModel(Concerts concerts){
        ConcertsModel model = new ConcertsModel();
        model.setId(concerts.getId());
        model.setCity(concerts.getCity());
        model.setAddress(concerts.getAddress());
        model.setDate(concerts.getDate());
        model.setTime(concerts.getTime());
        return model;
    }

    public ConcertsModel(){
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
