package com.example.leticoursework.client.gui.concerts;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class ConcertsModelGui<Concerts> extends AbstractListModel<Concerts> {
    private List<Concerts> list = new ArrayList<>();

    @Override
    public int getSize() {
        return list.size();
    }

    @Override
    public Concerts getElementAt(int index) {
        return list.get(index);
    }

    public void setMusicianList(List<Concerts> concertsList){
        list = concertsList;
    }

    public void addConcerts(Concerts concerts) {
        list.add(concerts);
        fireIntervalAdded(concerts,list.size()-1, list.size()-1);

    }

    public void delConcerts(Concerts concerts) {
        list.remove(concerts);
        fireIntervalRemoved(concerts, list.size(), list.size());
    }

    public void editConcerts(Concerts concerts){

    }

}
