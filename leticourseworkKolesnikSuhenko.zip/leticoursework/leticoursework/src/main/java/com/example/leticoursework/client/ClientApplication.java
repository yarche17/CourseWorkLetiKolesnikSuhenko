package com.example.leticoursework.client;

import com.example.leticoursework.client.gui.MainFrame;

import javax.swing.*;
import javax.swing.plaf.metal.MetalLookAndFeel;

public class ClientApplication {
    public static void main(String[] args) {








        try {
            UIManager.setLookAndFeel(new MetalLookAndFeel());
        } catch (UnsupportedLookAndFeelException e) {
            System.out.println("Error");;
        }

        MainFrame frame = new MainFrame();
        frame.setSize(1024,640);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);





        frame.setVisible(true);
    }
}
