package com.example.leticoursework.client.gui;

import java.awt.*;

public class ColoriesStyle {
    public Font fontHead = new Font("Segoe UI Black", Font.BOLD, 15);
    public Font fontMain = new Font("Segoe UI Black", Font.PLAIN, 14);
    public Color background = new Color(18,18,18);
    public Color background1 = new Color(24,24,24);
    public Color textBackground = new Color(24,24,24);
    public Color text = new Color(86,179,95);
}
