package com.example.leticoursework.client.gui.musician;

import com.example.leticoursework.server.entity.Musician;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class MusicianModelGui<Musician> extends AbstractListModel<Musician> {
    private List<Musician> list = new ArrayList<>();



    @Override
    public int getSize() {
        return list.size();
    } //Размер массива данных в списке

    @Override
    public Musician getElementAt(int index) { return list.get(index); } //Извлечение элемента

    public void setMusicianList(List<Musician> musicianList){
        list = musicianList;
    }


    public void addMusician(Musician musician) {
        list.add(musician);
        fireIntervalAdded(musician,list.size()-1, list.size()-1);

    }

    public void delMusician(Musician musician) {
        list.remove(musician);
        fireIntervalRemoved(musician, list.size(), list.size());
    }


}
