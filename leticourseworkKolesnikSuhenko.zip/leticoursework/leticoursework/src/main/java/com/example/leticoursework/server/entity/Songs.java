package com.example.leticoursework.server.entity;

import jakarta.persistence.*;

@Entity
public class Songs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String genre;
    private String duration;
    private String lyrics;

    @ManyToOne
    @JoinColumn(name = "musician_id")
    private Musician musicianN;

    public Songs(){
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getLyrics() {
        return lyrics;
    }

    public void setLyrics(String lyrics) {
        this.lyrics = lyrics;
    }

    public Musician getMusicianN() {
        return musicianN;
    }

    public void setMusicianN(Musician musicianN) {
        this.musicianN = musicianN;
    }
}
