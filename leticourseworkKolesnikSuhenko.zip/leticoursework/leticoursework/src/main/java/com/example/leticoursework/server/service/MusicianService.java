package com.example.leticoursework.server.service;

import com.example.leticoursework.server.entity.Musician;
import com.example.leticoursework.server.model.MusicianModel;
import com.example.leticoursework.server.repository.MusicianRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MusicianService {
    @Autowired
    private MusicianRepo musicianRepo;


    public MusicianModel addMusician(Musician musician){

        return MusicianModel.toModel(musicianRepo.save(musician));
    }

    public MusicianModel getMusician(Long id){
        Musician musician = musicianRepo.findById(id).get();
        return MusicianModel.toModel(musician);
    }

    public Long delMusician(Long id){
        musicianRepo.deleteById(id);
        return id;
    }

    public MusicianModel editMusician(Long id, Musician musician){
        Musician musician1 = musicianRepo.findById(id).get();
        musician1.setName(musician.getName());
        musician1.setFio(musician.getFio());
        musician1.setCountry(musician.getCountry());
        musician1.setb_date(musician.getb_date());
        return MusicianModel.toModel(musicianRepo.save(musician1));

    }

}


