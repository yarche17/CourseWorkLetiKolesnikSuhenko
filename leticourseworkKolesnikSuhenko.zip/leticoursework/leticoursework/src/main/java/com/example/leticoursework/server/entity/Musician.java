package com.example.leticoursework.server.entity;


import jakarta.persistence.*;

import java.util.List;


@Entity
public class Musician {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;
    private String fio;
    private String country;
    private String b_date;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "musicianN")
    private List<Songs> songs;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "musicianN")
    private List<Concerts> concerts;

    public Musician(){
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFio() {
        return this.fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getb_date() {
        return this.b_date;
    }

    public void setb_date(String bDate) {
        this.b_date = bDate;
    }


    public List<Songs> getSongs() {
        return songs;
    }

    public void setSongs(List<Songs> songs) {
        this.songs = songs;
    }

    public List<Concerts> getConcerts() {
        return concerts;
    }

    public void setConcerts(List<Concerts> concerts) {
        this.concerts = concerts;
    }
}
