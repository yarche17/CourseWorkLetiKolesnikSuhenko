package com.example.leticoursework.server.service;

import com.example.leticoursework.server.entity.Concerts;
import com.example.leticoursework.server.entity.Musician;
import com.example.leticoursework.server.model.ConcertsModel;
import com.example.leticoursework.server.repository.ConcertsRepo;
import com.example.leticoursework.server.repository.MusicianRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ConcertsService {
    @Autowired
    private ConcertsRepo concertsRepo;
    @Autowired
    private MusicianRepo musicianRepo;


    public ConcertsModel addConcerts(Concerts concerts, Long musicianId){
        Musician musician = musicianRepo.findById(musicianId).get();
        concerts.setMusicianN(musician);
        return ConcertsModel.toModel(concertsRepo.save(concerts));
    }

    public ConcertsModel getConcerts(Long id){
        Concerts concerts = concertsRepo.findById(id).get();
        return ConcertsModel.toModel(concerts);
    }

    public Long delConcerts(Long id){
        concertsRepo.deleteById(id);
        return id;
    }

    public ConcertsModel editConcerts(Long id, Concerts concerts) {
        Concerts concerts1 = concertsRepo.findById(id).get();
        concerts1.setCountry(concerts.getCountry());
        concerts1.setCity(concerts.getCity());
        concerts1.setAddress(concerts.getAddress());
        concerts1.setDate(concerts.getDate());
        concerts1.setTime(concerts.getTime());
        return ConcertsModel.toModel(concertsRepo.save(concerts1));
    }



}
