package com.example.leticoursework.client.gui.musician;

import com.example.leticoursework.server.entity.Musician;
import javax.swing.*;
import java.awt.*;

public class MusicianRenderer extends DefaultListCellRenderer { //представление обьекта в списке
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        setText(((Musician)value).getName());
        return this;
    }
}

