package com.example.leticoursework.client.gui.concerts;

import com.example.leticoursework.server.entity.Concerts;
import javax.swing.*;
import java.awt.*;

public class ConcertsRenderer extends DefaultListCellRenderer {
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        setText(((Concerts)value).getAddress());
        return this;
    }

}